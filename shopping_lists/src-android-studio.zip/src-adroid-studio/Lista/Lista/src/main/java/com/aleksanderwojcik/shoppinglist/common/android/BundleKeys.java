package com.aleksanderwojcik.shoppinglist.common.android;

/**
 * Created by AXELA on 2014-11-25.
 */
public class BundleKeys {
    public final static String PRODUCT_ID = "ASSDXS456";
    public final static String PRODUCT_ACTION = "ASDFS456";
    public final static String PRODUCT_DESCRIPTION = "SASDFS456A";
    public static final String NEW_SHOPPING_LIST_NAME = "2341212334";
    public static final String NEW_SHOPPING_LIST_ID = "ASDX";
    public static final String SHOPPING_LIST_ID = "34FSDF34QWDSFCASD";
    public static final String PRODUCT_NAME = "23RSAFS";
    public static final String PRODUCT_MEASURE = "23RSAFShvhj";
}
